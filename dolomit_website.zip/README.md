# Dolomit Nusantara Website

Website sederhana bertema dolomit untuk portfolio atau bisnis material.

## Fitur
- Landing page modern
- Form kontak sederhana
- Struktur mudah dikembangkan

## Cara Menjalankan
Buka file `index.html` di browser.

## Deploy
Bisa di-host via GitHub Pages.
